

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Buat Foto Baru</h1>
    </div>
    <div class="col-lg-8">
        <form method="post" action="/dashboard/posts" class="mb-5" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="JudulFoto" class="form-label">Judul</label>
                <input type="text" class="form-control " name="JudulFoto">

            </div>
            <div class="mb-3">
                <label for="DeskripsiFoto" class="form-label">Deskripsi</label>
                <input type="text" class="form-control" name="DeskripsiFoto">
            </div>
            <div class="mb-3">
                <label for="Album" class="form-label">Album</label>
                <select class="form-select" name="AlbumID">
                    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('AlbumID') == $album->AlbumID): ?>
                            <option value="<?php echo e($album->AlbumID); ?>" selected><?php echo e($album->NamaAlbum); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($album->AlbumID); ?>"><?php echo e($album->NamaAlbum); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="Foto" class="form-label">Post Image</label>
                <img class="img-preview img-fluid mb-3 col-sm-5">
                <input class="form-control" name="LokasiFile" type="file">
            </div>

            <button type="submit" class="btn btn-primary">Create Post</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/dashboard/posts/create.blade.php ENDPATH**/ ?>