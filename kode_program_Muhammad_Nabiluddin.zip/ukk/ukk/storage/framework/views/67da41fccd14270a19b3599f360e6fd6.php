

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Create new Album</h1>
    </div>
    <div class="col-lg-6">
        <form method="post" action="/dashboard/albums" class="mb-5">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="NamaAlbum" class="form-label">Nama Album</label>
                <input type="text" class="form-control" name="NamaAlbum"
                    required autofocus value="<?php echo e(old('name')); ?>">
            </div>
            <div class="mb-3">
                <label for="Deskripsi" class="form-label">Deskripsi</label>
                <input type="text" class="form-control" name="Deskripsi"required>
            </div>

            <button type="submit" class="btn btn-primary">Create Post</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/dashboard/albums/create.blade.php ENDPATH**/ ?>