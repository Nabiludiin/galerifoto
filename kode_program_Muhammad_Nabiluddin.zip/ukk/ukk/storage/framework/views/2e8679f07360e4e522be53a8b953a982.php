
<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('konten'); ?>
    <h1 class="mb-3 text-center"><?php echo e($title); ?></h1>

    

    <?php if($Foto->count()): ?>
        <div class="card mb-3">
            <div style="max-height: 400px; overflow:hidden; ">
                <img src="<?php echo e(Storage::url($Foto[0]->LokasiFile)); ?>" alt="<?php echo e($Foto[0]->JudulFoto); ?>" class="img-fluid">
            </div>

            <div class="card-body text-center">
                <h3 class="card-title">
                    <a href="/posts/<?php echo e($Foto[0]->JudulFoto); ?>" class="text-decoration-none text-dark">
                        <?php echo e($Foto[0]->JudulFoto); ?>

                    </a>
                </h3>
                <p>
                    <small class="text-muted">
                        By. <?php echo e($Foto[0]->author->Username); ?> in
                        <a href="/lihatAlbum/<?php echo e($Foto[0]->album->AlbumID); ?>" class="text-decoration-none">
                            <?php echo e($Foto[0]->album->NamaAlbum); ?>

                        </a> :
                        <?php echo e($Foto[0]->TanggalUnggah); ?>

                    </small>
                </p>
                <p class="card-text"><?php echo e($Foto[0]->DeskripsiFoto); ?></p>

                <?php if(session('data')): ?>
                    <a href="/posts/<?php echo e($Foto[0]->FotoID); ?>" class="text-decoration-none btn btn-primary">Lihat</a>
                <?php else: ?>
                    <button type="button" class="btn btn-primary" onclick="tampilkanPopup()">Lihat</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $Foto->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            
                            <div style="max-height: 400px; overflow:hidden;">
                                <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" alt="<?php echo e($foto->JudulFoto); ?>"
                                    class="img-fluid">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($foto->JudulFoto); ?></h5>
                                <p>
                                    <small class="text-muted">
                                        By. <?php echo e($foto->author->Username); ?> : <?php echo e($foto->TanggalUnggah); ?>

                                    </small>
                                </p>
                                <p class="card-text"><?php echo e($foto->DeskripsiFoto); ?></p>
                                <?php if(session('data')): ?>
                                    <a href="/posts/<?php echo e($foto->FotoID); ?>" class="btn btn-primary">Lihat</a>
                                <?php else: ?>
                                    <button type="button" class="btn btn-primary" onclick="tampilkanPopup()">Lihat</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php else: ?>
        <p class="text-center fs-4">No Image Found.</p>
    <?php endif; ?>

    <script>
        function tampilkanPopup() {
            var pesan = 'Anda harus login terlebih dahulu.';
            alert(pesan);
            window.location.href = '/login';
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/posts.blade.php ENDPATH**/ ?>