

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">My Image</h1>
    </div>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success col-lg-8" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="container">
        <a href="/dashboard/posts/create" class="btn btn-primary mb-3">Create new Image</a>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card">
                        <img src="<?php echo e(Storage::url($post->LokasiFile)); ?>" alt="<?php echo e($post->JudulFoto); ?>"
                            class="card-img-top img-fluid">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($post->JudulFoto); ?></h5>
                            <p class="card-text"><?php echo e($post->DeskripsiFoto); ?></p>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted"><?php echo e($post->TanggalUnggah); ?></small>
                            
                            <a href="/posts/<?php echo e($post->FotoID); ?>" class="btn btn-primary float-end">Lihat</a>
                            <a href="/hapusfoto/<?php echo e($post->FotoID); ?>" class="btn btn-danger float-end">Hapus</a>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/dashboard/posts/index.blade.php ENDPATH**/ ?>