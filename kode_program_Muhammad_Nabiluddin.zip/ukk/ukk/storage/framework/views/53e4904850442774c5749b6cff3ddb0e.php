

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Welcome Back, <?php echo e(session('data')->Username); ?></h1>
    </div>

    <div class="container">
        <div class="row justify-content-end">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="<?php echo e(Storage::url($post->LokasiFile)); ?>" alt="<?php echo e($post->JudulFoto); ?>" class="card-img-top img-fluid">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($post->JudulFoto); ?></h5>
                            <p>
                                <small class="text-muted">
                                    By. <?php echo e($post->author->Username); ?> in <a
                                        href="/lihatAlbum/<?php echo e($post->album->AlbumID); ?>"
                                        class="text-decoration-none"><?php echo e($post->album->NamaAlbum); ?></a>
                                </small>
                            </p>
                            <p class="card-text"><?php echo e($post->DeskripsiFoto); ?></p>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted"><?php echo e($post->TanggalUnggah); ?></small>
                            <a href="/posts/<?php echo e($post->FotoID); ?>" class="btn btn-primary float-end">Lihat</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/dashboard/index.blade.php ENDPATH**/ ?>