
<?php $__env->startSection('title', $album->NamaAlbum); ?>

<?php $__env->startSection('konten'); ?>
    <h1 class='mb-5'>Album : <?php echo e($album->NamaAlbum); ?></h1>

    <div class="container">
        <?php if($alb->count()): ?>
            <div class="row">
                <?php $__currentLoopData = $alb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="position-absolute px-3 py-2" style="background-color: rgba(0,0,0,0.7)">
                                <a href="/posts/<?php echo e($foto->FotoID); ?>" class="text-white text-decoration-none">
                                    <?php echo e($foto->JudulFoto); ?>

                                </a>
                            </div>
                            <div style="max-height: 400px; overflow:hidden;">
                                <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" alt="<?php echo e($foto->JudulFoto); ?>"
                                    class="img-fluid">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($foto->JudulFoto); ?></h5>
                                <p>
                                    <small class="text-muted">
                                        By. <a href="/posts?author=<?php echo e($foto->author->Username); ?>"
                                            class="text-decoration-none"><?php echo e($foto->author->Username); ?></a> :
                                        <?php echo e($foto->TanggalUnggah); ?>

                                    </small>
                                </p>
                                <p class="card-text"><?php echo e($foto->DeskripsiFoto); ?></p>
                                <?php if(session('data')): ?>
                                    <a href="/posts/<?php echo e($foto->FotoID); ?>" class="btn btn-primary">Lihat</a>
                                <?php else: ?>
                                    <button type="button" class="btn btn-primary" onclick="tampilkanPopup()">Lihat</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php else: ?>
            <p class="text-center fs-4">No Image Found.</p>
        <?php endif; ?>
    </div>
    <script>
        function tampilkanPopup() {
            // Menampilkan pesan teks
            var pesan = 'Anda harus login terlebih dahulu.';
            alert(pesan);
            // Atau, jika Anda ingin mengarahkan pengguna ke halaman tertentu setelah alert
            window.location.href = '/login'; // Ganti '/login' dengan URL halaman login Anda
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/lihatfotobyalbum.blade.php ENDPATH**/ ?>