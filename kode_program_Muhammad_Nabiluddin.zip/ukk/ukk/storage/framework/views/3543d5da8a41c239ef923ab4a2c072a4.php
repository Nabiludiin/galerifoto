
<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('konten'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h1 class="mb-3"><?php echo e($foto->JudulFoto); ?></h1>
                <p>By. <?php echo e($foto->author->Username); ?> in <a href="/lihatAlbum/<?php echo e($foto->album->AlbumID); ?>"
                        class="text-decoration-none"><?php echo e($foto->album->NamaAlbum); ?></a></p>
                <div style="max-height: 1000px; overflow:hidden;">
                    <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" alt="<?php echo e($foto->JudulFoto); ?>" class="img-fluid">
                </div>
                <article class="my-3 fs-5">
                    <p><?php echo e($foto->DeskripsiFoto); ?></p>
                </article>
                <div class="like-com">
                    <div class="user-prof"><i class="fa-solid fa-circle-user"></i> <?php echo e($foto->author->Username); ?>

                        <div class="ms-auto">
                            <?php if($cek = $like->where('UserID', session('data')->UserID)->where('FotoID', $foto->FotoID)->first()): ?>
                                
                                <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                                    <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                                </a>
                                <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                            <?php else: ?>
                                
                                <a href="/berilike/<?php echo e($foto->FotoID); ?>">
                                    <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                                </a>
                                <?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?>

                            <?php endif; ?>


                            
                            <i class="fa-regular fa-comment" style="font-size: 20px"></i>
                            <?php echo e($komen->count()); ?>

                            
                        </div>
                    </div>
                </div>
                <hr style="width: 100%; color: black; height: 1px;background-color: black;">
                <?php if($komen->isEmpty()): ?>
                    <div class="kom">
                        Belum ada komentar, jadilah pertama yang menanggapi!
                    </div>
                <?php else: ?>
                    
                    <?php $__currentLoopData = $komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="kom">
                            <div class="kom-left">
                                <div class="user-com"><i class="fa-solid fa-circle-user"></i>
                                    <?php if($namanya = $user2->where('UserID', $kom->UserID)->first()): ?>
                                        <?php echo e($namanya->Username); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="isi-com"><?php echo e($kom->IsiKomentar); ?></div>
                            </div>
                            <div class="tgl-kom">
                                <?php echo e($kom->TanggalKomentar); ?>

                                
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="create-kom">
                    <form action="/berikomen/<?php echo e($foto->FotoID); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required
                            class="isi-komen">
                        <button><i class="fa-solid fa-paper-plane"></i></button>
                    </form>
                </div>
                <button>
                    <a href="/posts" class="d-block mt-2">Back to posts</a>
                </button>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/post.blade.php ENDPATH**/ ?>