
<?php $__env->startSection('title','Album'); ?>

<?php $__env->startSection('konten'); ?>
    <h1 class='mb-5'><?php echo e($title); ?></h1>

    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-2 col-md-4">
                    
                        <a href="/lihatAlbum/<?php echo e($album->AlbumID); ?>">
                        <div class="card text-bg-dark">
                            <img src="https://source.unsplash.com/500x500?<?php echo e($album->NamaAlbum); ?>" class="card-img"
                                alt="<?php echo e($album->NamaAlbum); ?>">
                            <div class="card-img-overlay d-flex align-items-center p-0">
                                <h5 class="card-title text-center flex-fill p-3 fs-3"
                                    style="background-color: rgba(0,0,0,0.7)"><?php echo e($album->NamaAlbum); ?></h5>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\ukk\resources\views/albums.blade.php ENDPATH**/ ?>