<?php

use App\Models\Foto;
use App\Models\User;
use App\Models\Album;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DashboardAlbController;
use App\Http\Controllers\DashboardPostController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/posts', [FotoController::class, 'index']);
Route::get('posts/{post:JudulFoto}', [FotoController::class, 'show']);

Route::get('/edit/{FotoID}', [FotoController::class, 'edit']);
// Route::delete('/hapusfoto/{FotoID}', [FotoController::class, 'destroy']);
Route::get('/hapusfoto/{FotoID}', [FotoController::class, 'delete']);


Route::get('/albums', function () {
    return view('albums', [
        'title' => 'Post Album',
        'active' => 'Albums',
        'albums' => Album::all(),

    ]);
});

Route::get('/login', [LoginController::class, 'index'])->middleware('guest');
Route::post('/login/storelog', [LoginController::class, 'storelog']);

Route::post('/logout', [LoginController::class, 'logout']);

Route::get('/register', [RegisterController::class, 'viewreg'])->middleware('guest');
Route::post('/register/storereg', [RegisterController::class, 'storereg']);

Route::get('/dashboard', function () {
    return view('dashboard.index', [
        // 'posts' => Foto::where('UserID',session('data')->UserID)->get()
        'posts' => Foto::all()
    ]);
});


// Route::get('/dashboard/posts', [DashboardController::class, 'index']);
Route::resource('/dashboard/posts', DashboardPostController::class);
Route::resource('/dashboard/albums', DashboardAlbController::class);

Route::get('/berilike/{FotoID}', [FotoController::class, 'like']);
Route::post('/berikomen/{FotoID}', [FotoController::class, 'komen']);

Route::delete('/hapuskomen/{FotoID}', [FotoController::class, 'hapus']);

Route::get('/albums/{album}', [FotoController::class, 'tampilalbum']);
// Route::get('/lihatalbum/{NamaAlbum}', [PostController::class, 'masukalb']);
Route::get('/lihatAlbum/{AlbumID}', [FotoController::class, 'masukalb']);
