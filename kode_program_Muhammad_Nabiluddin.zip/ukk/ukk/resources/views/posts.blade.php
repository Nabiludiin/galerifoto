@extends('layouts.main')
@section('title', 'Beranda')

@section('konten')
    <h1 class="mb-3 text-center">{{ $title }}</h1>

    {{-- <div class="d-flex justify-content-center">
        {{ $Foto->links() }}
    </div> --}}

    @if ($Foto->count())
        <div class="card mb-3">
            <div style="max-height: 400px; overflow:hidden; ">
                <img src="{{ Storage::url($Foto[0]->LokasiFile) }}" alt="{{ $Foto[0]->JudulFoto }}" class="img-fluid">
            </div>

            <div class="card-body text-center">
                <h3 class="card-title">
                    <a href="/posts/{{ $Foto[0]->JudulFoto }}" class="text-decoration-none text-dark">
                        {{ $Foto[0]->JudulFoto }}
                    </a>
                </h3>
                <p>
                    <small class="text-muted">
                        By. {{ $Foto[0]->author->Username }} in
                        <a href="/lihatAlbum/{{ $Foto[0]->album->AlbumID }}" class="text-decoration-none">
                            {{ $Foto[0]->album->NamaAlbum }}
                        </a> :
                        {{ $Foto[0]->TanggalUnggah }}
                    </small>
                </p>
                <p class="card-text">{{ $Foto[0]->DeskripsiFoto }}</p>

                @if (session('data'))
                    <a href="/posts/{{ $Foto[0]->FotoID }}" class="text-decoration-none btn btn-primary">Lihat</a>
                @else
                    <button type="button" class="btn btn-primary" onclick="tampilkanPopup()">Lihat</button>
                @endif
            </div>
        </div>

        <div class="container">
            <div class="row">
                @foreach ($Foto->skip(1) as $foto)
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            {{-- <div class="position-absolute px-3 py-2" style="background-color: rgba(0,0,0,0.7)">
                                <a href="/posts?album={{ $foto->album->NamaAlbum }}"
                                    class="text-white text-decoration-none">
                                    {{ $foto->JudulFoto }}
                                </a>
                            </div> --}}
                            <div style="max-height: 400px; overflow:hidden;">
                                <img src="{{ Storage::url($foto->LokasiFile) }}" alt="{{ $foto->JudulFoto }}"
                                    class="img-fluid">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">{{ $foto->JudulFoto }}</h5>
                                <p>
                                    <small class="text-muted">
                                        By. {{ $foto->author->Username }} : {{ $foto->TanggalUnggah }}
                                    </small>
                                </p>
                                <p class="card-text">{{ $foto->DeskripsiFoto }}</p>
                                @if (session('data'))
                                    <a href="/posts/{{ $foto->FotoID }}" class="btn btn-primary">Lihat</a>
                                @else
                                    <button type="button" class="btn btn-primary" onclick="tampilkanPopup()">Lihat</button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @else
        <p class="text-center fs-4">No Image Found.</p>
    @endif

    <script>
        function tampilkanPopup() {
            var pesan = 'Anda harus login terlebih dahulu.';
            alert(pesan);
            window.location.href = '/login';
        }
    </script>

@endsection
