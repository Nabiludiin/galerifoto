@extends('layouts.main')
@section('title','Register')
    
@section('konten')
<div class="row justify-content-center">
    <div class="col-lg-5">
        <main class="form-registration w-100 m-auto">
            <h1 class="h3 mb-3 fw-normal text-center">Registration Form</h1>
            <form action="/register/storereg" method="POST">
                @csrf
                <div class="form-floating">
                    <div class="form-floating">
                        <input type="text" name="Username"class="form-control @error('Username') is-invalid @enderror" id="Username" placeholder="Username" required value="{{ old('Username') }}">
                        <label for="Username">Username</label>
                        @error('Username')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="form-floating">
                        <input type="Password" name="Password" class="form-control rounded-bottom @error('Password') is-invalid @enderror" id="Password"
                            placeholder="Password" required >
                        <label for="Password">Password</label>
                        @error('Password')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="form-floating">
                        <input type="Email" name="Email" class="form-control @error('Email') is-invalid @enderror" id="Email"
                            placeholder="name@example.com"required value="{{ old('Email') }}">
                        <label for="Email">Email address</label>
                        @error('Email')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="form-floating">
                    <input type="text" name="NamaLengkap"
                        class="form-control rounded-top @error('NamaLengkap') is-invalid @enderror" id="NamaLengkap"
                        placeholder="NamaLengkap" required value="{{ old('NamaLengkap') }}">
                    <label for="NamaLengkap">Name</label>
                    @error('NamaLengkap')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                    <div class="form-floating">
                    <input type="text" name="Alamat"
                        class="form-control rounded-top @error('Alamat') is-invalid @enderror" id="Alamat"
                        placeholder="Alamat" required value="{{ old('Alamat') }}">
                    <label for="Alamat">Alamat</label>
                    @error('Alamat')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <button class="w-100 btn btn-lg btn-primary mt-3" type="submit">Register</button>
            </form>
            <small class="d-block text-center mt-3">Already registered? <a href="/login">Login</a></small>
        </main>
    </div>
</div>
@endsection