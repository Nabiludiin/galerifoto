@extends('layouts.main')
@section('title', 'Beranda')

@section('konten')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h1 class="mb-3">{{ $foto->JudulFoto }}</h1>
                <p>By. {{ $foto->author->Username }} in <a href="/lihatAlbum/{{ $foto->album->AlbumID }}"
                        class="text-decoration-none">{{ $foto->album->NamaAlbum }}</a></p>
                <div style="max-height: 1000px; overflow:hidden;">
                    <img src="{{ Storage::url($foto->LokasiFile) }}" alt="{{ $foto->JudulFoto }}" class="img-fluid">
                </div>
                <article class="my-3 fs-5">
                    <p>{{ $foto->DeskripsiFoto }}</p>
                </article>
                <div class="like-com">
                    <div class="user-prof"><i class="fa-solid fa-circle-user"></i> {{ $foto->author->Username }}
                        <div class="ms-auto">
                            @if ($cek = $like->where('UserID', session('data')->UserID)->where('FotoID', $foto->FotoID)->first())
                                {{-- setelah user meng klik like --}}
                                <a href="/berilike/{{ $foto->FotoID }}">
                                    <i class="fa-solid fa-thumbs-up" style="font-size: 20px"></i>
                                </a>
                                {{ $like->where('FotoID', $foto->FotoID)->count() }}
                            @else
                                {{-- sebelum user mengklik like --}}
                                <a href="/berilike/{{ $foto->FotoID }}">
                                    <i class="fa-regular fa-thumbs-up" style="font-size: 20px"></i>
                                </a>
                                {{ $like->where('FotoID', $foto->FotoID)->count() }}
                            @endif


                            {{-- <div class="komentar"> --}}
                            <i class="fa-regular fa-comment" style="font-size: 20px"></i>
                            {{ $komen->count() }}
                            {{-- </div> --}}
                        </div>
                    </div>
                </div>
                <hr style="width: 100%; color: black; height: 1px;background-color: black;">
                @if ($komen->isEmpty())
                    <div class="kom">
                        Belum ada komentar, jadilah pertama yang menanggapi!
                    </div>
                @else
                    {{-- @foreach ($komen->sortByDesc('TanggalKomentar') as $kom) --}}
                    @foreach ($komen as $kom)
                        <div class="kom">
                            <div class="kom-left">
                                <div class="user-com"><i class="fa-solid fa-circle-user"></i>
                                    @if ($namanya = $user2->where('UserID', $kom->UserID)->first())
                                        {{ $namanya->Username }}
                                    @endif
                                </div>
                                <div class="isi-com">{{ $kom->IsiKomentar }}</div>
                            </div>
                            <div class="tgl-kom">
                                {{ $kom->TanggalKomentar }}
                                {{-- @if ($kom->UserID == session('data')->UserID)
                                    <form action="/hapuskomen/{{ $kom->FotoID }}" method="post">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus komentar ini?')">Hapus
                                            Komentar</button>
                                    </form>
                                @endif --}}
                            </div>
                        </div>
                    @endforeach
                @endif
                <div class="create-kom">
                    <form action="/berikomen/{{ $foto->FotoID }}" method="post">
                        @csrf
                        <input type="text" name="isi" placeholder="Masukkan komentar kamu..." required
                            class="isi-komen">
                        <button><i class="fa-solid fa-paper-plane"></i></button>
                    </form>
                </div>
                <button>
                    <a href="/posts" class="d-block mt-2">Back to posts</a>
                </button>
            </div>
        </div>
    </div>
    </div>
@endsection
