@extends('dashboard.layouts.main')

@section('container')
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Welcome Back, {{ session('data')->Username }}</h1>
    </div>

    <div class="container">
        <div class="row justify-content-end">
            @foreach ($posts as $post)
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="{{ Storage::url($post->LokasiFile) }}" alt="{{ $post->JudulFoto }}" class="card-img-top img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">{{ $post->JudulFoto }}</h5>
                            <p>
                                <small class="text-muted">
                                    By. {{ $post->author->Username }} in <a
                                        href="/lihatAlbum/{{ $post->album->AlbumID }}"
                                        class="text-decoration-none">{{ $post->album->NamaAlbum }}</a>
                                </small>
                            </p>
                            <p class="card-text">{{ $post->DeskripsiFoto }}</p>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">{{ $post->TanggalUnggah }}</small>
                            <a href="/posts/{{ $post->FotoID }}" class="btn btn-primary float-end">Lihat</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    
    


@endsection