@extends('dashboard.layouts.main')

@section('container')
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">My Image</h1>
    </div>

    @if (session()->has('success'))
        <div class="alert alert-success col-lg-8" role="alert">
            {{ session('success') }}
        </div>
    @endif

    <div class="container">
        <a href="/dashboard/posts/create" class="btn btn-primary mb-3">Create new Image</a>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            @foreach ($posts as $post)
                <div class="col">
                    <div class="card">
                        <img src="{{ Storage::url($post->LokasiFile) }}" alt="{{ $post->JudulFoto }}"
                            class="card-img-top img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">{{ $post->JudulFoto }}</h5>
                            <p class="card-text">{{ $post->DeskripsiFoto }}</p>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">{{ $post->TanggalUnggah }}</small>
                            {{-- <form action="/hapusfoto/{{ $post->FotoID }}" method="POST" class="d-inline">
                                @method('delete')
                                @csrf
                                <button class="btn btn-danger float-end" onclick="return confirm('Yakin ingin menghapus foto?')">Hapus</button>
                            </form> --}}
                            <a href="/posts/{{ $post->FotoID }}" class="btn btn-primary float-end">Lihat</a>
                            <a href="/hapusfoto/{{ $post->FotoID }}" class="btn btn-danger float-end">Hapus</a>
                            {{-- <a href="/edit/{{ $post->FotoID }}" class="btn btn-info" style="color: white">Edit</a> --}}
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
