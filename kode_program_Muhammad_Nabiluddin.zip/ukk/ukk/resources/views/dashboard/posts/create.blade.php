@extends('dashboard.layouts.main')

@section('container')
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Buat Foto Baru</h1>
    </div>
    <div class="col-lg-8">
        <form method="post" action="/dashboard/posts" class="mb-5" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label for="JudulFoto" class="form-label">Judul</label>
                <input type="text" class="form-control " name="JudulFoto">

            </div>
            <div class="mb-3">
                <label for="DeskripsiFoto" class="form-label">Deskripsi</label>
                <input type="text" class="form-control" name="DeskripsiFoto">
            </div>
            <div class="mb-3">
                <label for="Album" class="form-label">Album</label>
                <select class="form-select" name="AlbumID">
                    @foreach ($albums as $album)
                        @if (old('AlbumID') == $album->AlbumID)
                            <option value="{{ $album->AlbumID }}" selected>{{ $album->NamaAlbum }}</option>
                        @else
                            <option value="{{ $album->AlbumID }}">{{ $album->NamaAlbum }}</option>
                        @endif
                    @endforeach
                </select>
            </div>
            <div class="mb-3">
                <label for="Foto" class="form-label">Post Image</label>
                <img class="img-preview img-fluid mb-3 col-sm-5">
                <input class="form-control" name="LokasiFile" type="file">
            </div>

            <button type="submit" class="btn btn-primary">Create Post</button>
        </form>
    </div>
@endsection
