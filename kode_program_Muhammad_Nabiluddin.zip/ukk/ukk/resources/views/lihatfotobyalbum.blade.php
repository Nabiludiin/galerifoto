@extends('layouts.main')
@section('title', $album->NamaAlbum)

@section('konten')
    <h1 class='mb-5'>Album : {{ $album->NamaAlbum }}</h1>

    <div class="container">
        @if ($alb->count())
            <div class="row">
                @foreach ($alb as $foto)
                    {{-- Ubah $photos menjadi $alb sesuai dengan variabel yang dikirimkan dari controller --}}
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="position-absolute px-3 py-2" style="background-color: rgba(0,0,0,0.7)">
                                <a href="/posts/{{ $foto->FotoID }}" class="text-white text-decoration-none">
                                    {{ $foto->JudulFoto }}
                                </a>
                            </div>
                            <div style="max-height: 400px; overflow:hidden;">
                                <img src="{{ Storage::url($foto->LokasiFile) }}" alt="{{ $foto->JudulFoto }}"
                                    class="img-fluid">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">{{ $foto->JudulFoto }}</h5>
                                <p>
                                    <small class="text-muted">
                                        By. <a href="/posts?author={{ $foto->author->Username }}"
                                            class="text-decoration-none">{{ $foto->author->Username }}</a> :
                                        {{ $foto->TanggalUnggah }}
                                    </small>
                                </p>
                                <p class="card-text">{{ $foto->DeskripsiFoto }}</p>
                                @if (session('data'))
                                    <a href="/posts/{{ $foto->FotoID }}" class="btn btn-primary">Lihat</a>
                                @else
                                    <button type="button" class="btn btn-primary" onclick="tampilkanPopup()">Lihat</button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach

            </div>
        @else
            <p class="text-center fs-4">No Image Found.</p>
        @endif
    </div>
    <script>
        function tampilkanPopup() {
            // Menampilkan pesan teks
            var pesan = 'Anda harus login terlebih dahulu.';
            alert(pesan);
            // Atau, jika Anda ingin mengarahkan pengguna ke halaman tertentu setelah alert
            window.location.href = '/login'; // Ganti '/login' dengan URL halaman login Anda
        }
    </script>
@endsection
