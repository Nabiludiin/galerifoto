<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('foto', function (Blueprint $table) {
            $table->id('FotoID', 11);
            $table->string('JudulFoto', 255);
            $table->text('DeskripsiFoto');
            $table->date('TanggalUnggah')->useCurrent();
            $table->string('LokasiFile', 255);
            $table->foreignId('AlbumID')->constrained('album','AlbumID');
            $table->foreignId('UserID')->constrained('user','UserID');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('foto');
    }
};
