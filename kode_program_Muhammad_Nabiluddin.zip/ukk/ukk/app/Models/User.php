<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    use HasFactory;

    protected $table = 'User';
    public $timestamps = false;
    protected $guarded = ['UserID'];
    protected $primaryKey = 'UserID';


    public function foto()
    {
        return $this->hasMany(Foto::class);
    }
}
