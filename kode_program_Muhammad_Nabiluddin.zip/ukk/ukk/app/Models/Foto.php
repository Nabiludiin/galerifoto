<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Foto extends Model
{
    use HasFactory;
    protected $table = 'Foto';
    public $timestamps = false;
    protected $guarded = [];
    protected $primaryKey = 'FotoID';
    protected $with = ['album', 'author'];

    public function album()
    {
        return $this->belongsTo(Album::class, 'AlbumID');
    }
    public function author()
    {
        return $this->belongsTo(User::class, 'UserID');
    }
    public function likes()
    {
        return $this->hasMany(LikeFoto::class);
    }

    public function comments()
    {
        return $this->hasMany(KomentarFoto::class);
    }
}
