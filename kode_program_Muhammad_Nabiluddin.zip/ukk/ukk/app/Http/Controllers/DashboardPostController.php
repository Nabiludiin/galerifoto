<?php

namespace App\Http\Controllers;

use App\Models\Foto;
use App\Models\Album;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;


class DashboardPostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('dashboard.posts.index', [
            // 'posts' => Foto::where('UserID', auth()->user()->id)->get()
            'posts' => Foto::where('UserID', session('data')->UserID)->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dashboard.posts.create', [
            'albums' => Album::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if ($request->hasFile('LokasiFile')) {

            $locate = $request->file('LokasiFile')->store('public/img');
            $data = new Foto();
            $data->JudulFoto = $request->input('JudulFoto');
            $data->DeskripsiFoto = $request->input('DeskripsiFoto');
            $data->TanggalUnggah = Carbon::now();
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->input('AlbumID');
            $data->UserID = session('data')->UserID;
            $data->save();
            return redirect('/dashboard/posts')->with('success', 'Foto Berhasil Ditambahkan');
        } else {
            echo "Foto Ga Kekirim";
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Foto $post)
    {
        // return view('dashboard.posts.show', [
        //     "post" => $post
        // ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Foto $foto)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Foto $foto)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    
    public function destroy(Foto $foto)
    {
        if ($foto->LokasiFile) {
            Storage::delete($foto->LokasiFile);
        }
        Foto::destroy($foto->FotoID);
        return redirect('/dashboard/posts')->with('success', 'Post has been deleted!');
    }
}
