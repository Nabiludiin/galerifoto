<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;


class LoginController extends Controller
{
    public function index()
    {
        return view('login', [
            'title' => 'Login',
            'active' => 'login'
        ]);
    }
    //aksi login
    public function storelog(Request $request)
    {
        $data = User::where('Password', $request->input('Password'))
            ->where('Email', $request->input('Email'))
            ->first();
        if ($data === null) {
            return redirect('/login')->with('pesan', 'Password / Email Salah!!!');
        } else {

            session()->put('data', $data);
            return redirect('/dashboard');
        }
    }
    public function logout()
    {
        Auth::logout();

        request()->session()->invalidate();
        request()->session()->regenerateToken();
        return redirect('/posts');
    }
}
