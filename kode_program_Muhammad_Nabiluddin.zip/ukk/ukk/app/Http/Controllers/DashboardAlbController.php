<?php

namespace App\Http\Controllers;

use App\Models\Album;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DashboardAlbController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('dashboard.albums.index', [
            // 'posts' => Foto::where('UserID', auth()->user()->id)->get()
            // 'albums' => Album::all()
            'albums' => Album::where('UserID',session('data')->UserID)->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dashboard.albums.create');
        
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = new Album;
        $data->NamaAlbum = $request->input('NamaAlbum');
        $data->Deskripsi = $request->input('Deskripsi');
        $data->TanggalDibuat = Carbon::now();
        $data->UserID = session('data')->UserID;
        $data->save();

        return redirect('/dashboard/albums')->with('success', 'Album Berhasil Ditambahkan');
    }

    /**
     * Display the specified resource.
     */
    public function show(Album $album)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Album $album)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Album $album)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Album $album)
    {
        //
    }
}
