<?php

namespace App\Http\Controllers;

use App\Models\Foto;
use App\Models\Album;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        return view('dashboard.posts.index', [
            // 'posts' => Foto::where('UserID', auth()->user()->id)->get()
            'posts' => Foto::where('UserID', session('data')->UserID)->get()
        ]);
    }

    
    public function create()
    {
        return view('dashboard.posts.create', [
            'albums' => Album::all()
        ]);
    }


    public function store(Request $request)
    {
        if ($request->hasFile('LokasiFile')) {

            $locate = $request->file('LokasiFile')->store('public/img');
            $data = new Foto();
            $data->JudulFoto = $request->input('JudulFoto');
            $data->DeskripsiFoto = $request->input('DeskripsiFoto');
            $data->TanggalUnggah = Carbon::now();
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->input('AlbumID');
            $data->UserID = session('data')->UserID;
            $data->save();
            return redirect('/dashboard/posts')->with('success', 'Foto Berhasil Ditambahkan');
        } else {
            echo "Foto Ga Kekirim";
        }
    }
}
