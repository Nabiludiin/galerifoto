<?php

namespace App\Http\Controllers;

use App\Models\Foto;
use App\Models\Album;
use App\Models\KomentarFoto;
use App\Models\LikeFoto;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class FotoController extends Controller
{
    public function index()
    {
        return view('posts', [
            'title' => "All Images",
            "active" => "Posts",
            "Foto" => Foto::all(),



            // "Foto" => Foto::orderBy('TanggalUnggah', 'desc')->paginate(7)->withQueryString(),
            // "Foto" => Foto::orderBy('TanggalUnggah', 'desc')->get(),
        ]);
    }

    public function show($FotoID)
    {
        return view('post', [

            "title" => "Single Post",
            "active" => "Posts",
            'like' => Likefoto::all(),
            'foto' => Foto::find($FotoID),
            'komen' => KomentarFoto::where('FotoID', $FotoID)->get(),
            'user2' => User::all(),


            // 'user' => User::find(UserID)

        ]);
    }

    public function tampilalbum()
    {
        $albums = Album::all();

        return view('albums', [
            'title' => 'Post Album',
            'active' => 'Albums',
            'albums' => $albums,
        ]);
    }

    public function masukalb($AlbumID)
    {
        return view('lihatfotobyalbum', [
            //ambil fto berdasrkn albumid
            "alb" => Foto::where('AlbumID', $AlbumID)->get(),
            //ambl data album berdsarkan albumid
            "album" => Album::find($AlbumID),
            "active" => "Albums",


        ]);
    }
    public function like($FotoID)
    {
        $cek = Likefoto::where('UserID', session('data')->UserID)->where('FotoID', $FotoID)->first();
        if (!$cek) {
            $like = new Likefoto;
            $like->FotoID = $FotoID;
            $like->UserID = session('data')->UserID;
            $like->TanggalLike = Carbon::now();
            $like->save();

            return redirect()->back();
        } else {
            $cek->delete();
            return redirect()->back();
        }
    }
    public function komen($FotoID, Request $req)
    {
        $komen = new Komentarfoto;
        $komen->FotoID = $FotoID;
        $komen->UserID = session('data')->UserID;
        $komen->IsiKomentar = $req->input('isi');
        $komen->TanggalKomentar = Carbon::now();
        $komen->save();

        return redirect()->back();
    }

    public function delete($FotoID)
    {
        KomentarFoto::where('FotoID', $FotoID)->delete();
        LikeFoto::where('FotoID', $FotoID)->delete();

        $foto = Foto::find($FotoID);
        $foto->delete();

        return redirect('/dashboard/posts')->with('success', 'Foto berhasil dihapus!');
    }

    public function edit($FotoID)
    {
        $foto = Foto::find($FotoID);

        return redirect('dashboard.posts.edit', compact('foto'));
    }

    // public function destroy(Foto $foto)
    // {
    //     if ($foto->LokasiFile) {
    //         Storage::delete($foto->LokasiFile);
    //     }
    //     Foto::destroy($foto->FotoID);
    //     return redirect('/dashboard/posts')->with('success', 'Post has been deleted!');
    // }
    //     public function hapus($FotoID)
    // {
    //     $comment = KomentarFoto::findOrFail($FotoID);
    //     dd($comment->FotoID);
    //     if ($comment->UserID == session('data')->UserID) {
    //         dd($comment->delete());
    //         return redirect()->back()->with('success', 'Komentar berhasil dihapus');
    //     } else {
    //         return redirect()->back()->with('error', 'Anda tidak memiliki izin untuk menghapus komentar ini');
    //     }
    // }

}
