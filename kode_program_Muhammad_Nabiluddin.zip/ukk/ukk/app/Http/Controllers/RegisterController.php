<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    public function viewreg()
    {
        return view('register', [
            'title' => 'Register',
            'active' => 'Register'
        ]);
    }
    //aksi register
    public function storereg(Request $request)
    {
        $data = new User();
        $data->Username = $request->input('Username');
        $data->Password = $request->input('Password');
        $data->Email = $request->input('Email');
        $data->NamaLengkap = $request->input('NamaLengkap');
        $data->Alamat = $request->input('Alamat');
        $data->save();
        return redirect('/login')->with('success', 'Registration successfull!');
    }
}